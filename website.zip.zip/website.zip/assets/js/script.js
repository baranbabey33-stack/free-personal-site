document.addEventListener('DOMContentLoaded', () => {
    // Initialize AOS (Animate On Scroll)
    AOS.init({
        duration: 800,
        once: true,
        mirror: false,
        disable: 'mobile' // Disable AOS on mobile for performance if needed
    });

    // Particles.js configuration
    if (typeof particlesJS !== 'undefined') {
        particlesJS('particles-js', {
            "particles": {
                "number": {
                    "value": 80,
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": {
                    "value": "#ffffff" // Particle color (white for light mode, adjust for dark)
                },
                "shape": {
                    "type": "circle",
                    "stroke": {
                        "width": 0,
                        "color": "#000000"
                    },
                    "polygon": {
                        "nb_sides": 5
                    },
                    "image": {
                        "src": "img/github.svg",
                        "width": 100,
                        "height": 100
                    }
                },
                "opacity": {
                    "value": 0.5,
                    "random": false,
                    "anim": {
                        "enable": false,
                        "speed": 1,
                        "opacity_min": 0.1,
                        "sync": false
                    }
                },
                "size": {
                    "value": 3,
                    "random": true,
                    "anim": {
                        "enable": false,
                        "speed": 40,
                        "size_min": 0.1,
                        "sync": false
                    }
                },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#ffffff", // Line color (white for light mode, adjust for dark)
                    "opacity": 0.4,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 6,
                    "direction": "none",
                    "random": false,
                    "straight": false,
                    "out_mode": "out",
                    "bounce": false,
                    "attract": {
                        "enable": false,
                        "rotateX": 600,
                        "rotateY": 1200
                    }
                }
            },
            "interactivity": {
                "detect_on": "canvas",
                "events": {
                    "onhover": {
                        "enable": true,
                        "mode": "grab"
                    },
                    "onclick": {
                        "enable": true,
                        "mode": "push"
                    },
                    "resize": true
                },
                "modes": {
                    "grab": {
                        "distance": 140,
                        "line_linked": {
                            "opacity": 1
                        }
                    },
                    "bubble": {
                        "distance": 400,
                        "size": 40,
                        "duration": 2,
                        "opacity": 8,
                        "speed": 3
                    },
                    "repulse": {
                        "distance": 200,
                        "duration": 0.4
                    },
                    "push": {
                        "particles_nb": 4
                    },
                    "remove": {
                        "particles_nb": 2
                    }
                }
            },
            "retina_detect": true
        });

        // Function to update particle colors based on theme
        const updateParticlesTheme = () => {
            const isDarkMode = document.body.classList.contains('dark-mode');
            const particleColor = isDarkMode ? "#3498db" : "#ffffff"; // Blue in dark, white in light
            const lineColor = isDarkMode ? "#2ecc71" : "#ffffff"; // Green in dark, white in light

            if (window.particlesJS && window.particlesJS.particles) {
                // Update particle color
                window.particlesJS.particles.color.value = particleColor;
                // Update line color
                window.particlesJS.particles.line_linked.color = lineColor;
                // Redraw particles to apply changes
                window.particlesJS.fn.particlesRefresh();
            }
        };

        // Initial particle theme update
        updateParticlesTheme();

        // Listen for theme changes to update particles
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', updateParticlesTheme);
        }
    }


    // Typing Effect for Hero Section
    const typedTextSpan = document.querySelector(".typing-text");
    if (typedTextSpan) {
        const textLoad = () => {
            setTimeout(() => {
                typedTextSpan.textContent = "a Software Engineer.";
            }, 0);
            setTimeout(() => {
                typedTextSpan.textContent = "a Web Developer.";
            }, 4000);
            setTimeout(() => {
                typedTextSpan.textContent = "a Problem Solver.";
            }, 8000);
        }
        textLoad();
        setInterval(textLoad, 12000);
    }

    // Smooth Scrolling for Navigation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });

            // Close mobile menu after clicking a link
            const navLinks = document.querySelector('.nav-links');
            const hamburger = document.querySelector('.hamburger-menu');
            if (navLinks && navLinks.classList.contains('active')) {
                navLinks.classList.remove('active');
                hamburger.classList.remove('active');
            }
        });
    });

    // Active Navigation Link Highlighting (for single-page navigation)
    const sections = document.querySelectorAll('section');
    const navItems = document.querySelectorAll('.nav-item');

    window.addEventListener('scroll', () => {
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            if (pageYOffset >= sectionTop - sectionHeight / 3) {
                current = section.getAttribute('id');
            }
        });

        navItems.forEach(item => {
            item.classList.remove('active');
            if (item.getAttribute('data-section') === current) {
                item.classList.add('active');
            }
        });
    });


    // Hamburger Menu functionality
    const hamburger = document.querySelector('.hamburger-menu');
    const navLinks = document.querySelector('.nav-links');

    if (hamburger && navLinks) {
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            hamburger.classList.toggle('active'); // Optional: for animating hamburger icon
        });
    }

    // Theme Toggle Functionality
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        // Check local storage for theme preference
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            document.body.classList.add(savedTheme);
        } else {
            // Default to light mode if no preference saved
            document.body.classList.add('light-mode');
        }

        themeToggle.addEventListener('click', () => {
            if (document.body.classList.contains('light-mode')) {
                document.body.classList.replace('light-mode', 'dark-mode');
                localStorage.setItem('theme', 'dark-mode');
            } else {
                document.body.classList.replace('dark-mode', 'light-mode');
                localStorage.setItem('theme', 'light-mode');
            }
        });
    }


    // Contact Form Validation and Submission (basic example)
    const contactForm = document.getElementById('contact-form');
    const formMessage = document.getElementById('form-message');

    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();

            let isValid = true;
            const nameInput = this.querySelector('#name');
            const emailInput = this.querySelector('#email');
            const subjectInput = this.querySelector('#subject');
            const messageInput = this.querySelector('#message');

            // Simple validation example
            if (nameInput.value.trim() === '') {
                displayError(nameInput, 'Name cannot be empty');
                isValid = false;
            } else {
                clearError(nameInput);
            }

            if (emailInput.value.trim() === '' || !isValidEmail(emailInput.value)) {
                displayError(emailInput, 'Please enter a valid email address');
                isValid = false;
            } else {
                clearError(emailInput);
            }

            if (subjectInput.value.trim() === '') {
                displayError(subjectInput, 'Subject cannot be empty');
                isValid = false;
            } else {
                clearError(subjectInput);
            }

            if (messageInput.value.trim() === '') {
                displayError(messageInput, 'Message cannot be empty');
                isValid = false;
            } else {
                clearError(messageInput);
            }

            if (isValid) {
                // Simulate form submission
                console.log('Form data:', {
                    name: nameInput.value,
                    email: emailInput.value,
                    subject: subjectInput.value,
                    message: messageInput.value
                });

                displayFormMessage('Thank you for your message! I will get back to you soon.', 'success');
                contactForm.reset(); // Clear the form
            } else {
                displayFormMessage('Please correct the errors in the form.', 'error');
            }
        });
    }

    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    }

    function displayError(inputElement, message) {
        const formGroup = inputElement.closest('.form-group');
        const errorMessageSpan = formGroup.querySelector('.error-message');
        if (errorMessageSpan) {
            errorMessageSpan.textContent = message;
        }
        inputElement.classList.add('error-input'); // Add a class for styling invalid input
    }

    function clearError(inputElement) {
        const formGroup = inputElement.closest('.form-group');
        const errorMessageSpan = formGroup.querySelector('.error-message');
        if (errorMessageSpan) {
            errorMessageSpan.textContent = '';
        }
        inputElement.classList.remove('error-input');
    }

    function displayFormMessage(message, type) {
        if (formMessage) {
            formMessage.textContent = message;
            formMessage.className = `form-message ${type}`; // Add success or error class
            formMessage.style.display = 'block';
            // Optional: Hide message after a few seconds
            setTimeout(() => {
                formMessage.style.display = 'none';
            }, 5000);
        }
    }

    // Custom Cursor logic
    const cursor = document.querySelector(".custom-cursor");
    const follower = document.querySelector(".custom-cursor-follower");
    if (cursor && follower) {
        document.addEventListener("mousemove", (e) => {
            cursor.style.left = e.clientX + "px";
            cursor.style.top = e.clientY + "px";
            follower.style.left = e.clientX + "px";
            follower.style.top = e.clientY + "px";
        });
    }
});